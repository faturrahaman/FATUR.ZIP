const animemenu = (prefix) => { 
	return `
╔══✪〘 ANIME 〙✪══
║
╠➥ *${prefix}randomanime*
╠➥ *${prefix}waifu*
╠➥ *${prefix}waifu2*
╠➥ *${prefix}nekonime*
╠➥ *${prefix}wibu*
╠➥ *${prefix}wait*
╠➥ *${prefix}inu*
╠➥ *${prefix}pokemon*
╠➥ *${prefix}naruto*
╠➥ *${prefix}hinata*
╠➥ *${prefix}sasuke*
╠➥ *${prefix}sakura*
╠➥ *${prefix}boruto*
╠➥ *${prefix}minato*
╠➥ *${prefix}loli*
╠➥ *${prefix}loli2*
╠➥ *${prefix}rize*
╠➥ *${prefix}akira*
╠➥ *${prefix}itori*
╠➥ *${prefix}kurumi*
╠➥ *${prefix}miku*
║
╚═〘 DARK BOT 〙`
}
exports.animemenu = animemenu